<div class="modal-body p-4 added-to-cart">
    <div class="text-center text-danger">
        <h2><?php echo e(__('oops..')); ?></h2>
        <h3><?php echo e(__('This item is out of stock!')); ?></h3>
    </div>
    <div class="text-center mt-5">
        <button class="btn btn-styled btn-base-1 btn-outline" data-dismiss="modal"><?php echo e(__('Back to shopping')); ?></button>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\revel_ecommerce\resources\views/frontend/partials/outOfStockCart.blade.php ENDPATH**/ ?>